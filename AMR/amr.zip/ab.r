library(reshape2)
library(plyr)

## Read data
df <- read.csv2("test.csv", as.is=TRUE, na.strings="")

## Create an unique identifier for each observations
df$id <- seq_len(nrow(df))

## Go from wide to long format
df <- melt(df, "id")

## Remove all NA values due to non existing data in cells
df <- df[complete.cases(df),]

## Clean cells
df$value[df$value == "<0,031"] <- "0,031"
df$value[df$value == "<0,063"] <- "0,063"
df$value[df$value == "<0,125"] <- "0,125"
df$value[df$value == "<0,25"] <- "0,25"
df$value[df$value == "<0,5"] <- "0,5"
df$value[df$value == "<2"] <- "2"
df$value[df$value == ">32"] <- "64"
df$value[df$value == ">4"] <- "8"
df$value[df$value == ">8"] <- "16"

df <- ddply(df, ~variable+value, nrow)
colnames(df) <- c("Substance", "MIC", "n")
df <- ddply(df, ~Substance, function(x) {
    cbind(x, N = sum(x$n))
})
df$p <- sprintf("%.1f", 100*df$n / df$N)
df$p <- sub("[.]", ",", df$p)
df <- dcast(df, Substance~MIC, value.var="p", fill="")
df <- df[, c("Substance", "0,031", "0,063", "0,125", "0,25", "0,5",
             "1", "2", "4", "8", "16", "32", "64", "128", ">128")]
df$Substance <- as.character(df$Substance)
df <- df[order(df$Substance),]
write.csv2(df, "result.csv", row.names=FALSE)
